package com.secure.notes.models;

public enum AppRole {
    ROLE_USER,
    ROLE_ADMIN
}




